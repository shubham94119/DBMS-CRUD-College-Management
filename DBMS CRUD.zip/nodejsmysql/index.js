

/// getting data from form

var con = require("./connection");
var express = require('express');

var app = express();
var bodyparser = require('body-parser');
app.use(bodyparser.json());

app.use(bodyparser.urlencoded({extended : true}));
app.set('view engine','ejs');

app.get('/',function(req,res){
    res.sendFile(__dirname+'/index.html');
});

app.post('/',function(req,res){
    console.log(req.body);
    var name1 = req.body.name1;
    var name2 = req.body.name2;
    var email = req.body.email;
    var rno = req.body.rno;
    var branch = req.body.branch;
    var semester = req.body.semester;
    var dob = req.body.dob;
    var grade = req.body.grade;


    //   student_f_name ,  student_rollnumber ,  student_I_name


 con.connect(function(error){
    if(error) throw error;

    var sql ="INSERT INTO STUDENT(student_f_name,student_I_name,student_rollnumber,grade,dob,semester,branch,email) VALUES('"+name1+"','"+name2+"','"+rno+"','"+grade+"','"+dob+"','"+semester+"','"+branch+"','"+email+"') ";

 con.query(sql, function(error,result){
        if (error)  throw error;
        res.redirect('/students');
     // res.send('Student Register successfull'+result.insertId);
//         console.log(result);              
    })
   


});

});

app.get('/students',function(req,res){
    con.connect(function(error){
          if(error) console.log(error);

          var sql ="select * from student";
          con.query(sql,function(error,result){
            if(error) console.log(error);
            // res.send(result);
            console.log(result);
            res.render(__dirname+"/student",{Students:result});
          });
    });
});

app.get('/delete-student',function(req,res){
    
    con.connect(function(error){
        if(error) console.log(error);

        var sql ="delete from student where student_rollnumber=?";
        var id =req.query.student_rollnumber;
        con.query(sql,[id],function(error,result){
          if(error) console.log(error);

          res.redirect('/students');
        });
  });

});

app.get('/update-student',function(req,res){
    
    con.connect(function(error){
        if(error) console.log(error);

        var sql ="select * from student where student_rollnumber=?";
        var id =req.query.student_rollnumber;
        con.query(sql,[id],function(error,result){
          if(error) console.log(error);

      
          res.render(__dirname+"/update-student",{student : result});
        });
  });



});
app.post('/update-student',function(req,res){

// student_f_name,student_I_name,student_rollnumber

var name1 = req.body.name1;
var name2 = req.body.name2;
var email = req.body.email;
var rno = req.body.rno;
var branch = req.body.branch;
var semester = req.body.semester;
var dob = req.body.dob;
var grade = req.body.grade;

    
    con.connect(function(error){
        if(error) console.log(error);

        var sql ="UPDATE student set student_f_name=?,student_I_name=?,email=?,student_rollnumber=?,branch=?,semester=?,dob=?,grade=? where student_rollnumber=? ";
        var id =req.query.student_rollnumber;
        con.query(sql,[name1,name2, email, rno,branch,semester,dob,grade, id],function(error,result){
          if(error) console.log(error);
            res.redirect('/students');
        });
  });

});

app.get('/er.html', (req, res) => { 
  res.sendFile(__dirname + '/er.html'); 
});




app.listen(8000);



