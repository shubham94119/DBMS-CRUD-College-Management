var mysql = require("mysql");

var con = mysql.createConnection({
    host : "localhost",
    user : "root",
    password : "Sh@94411",
    database : "iiitbh"
});


module.exports=con;
